Our work was implemented in the directory `PW_4/pw4/virtualprototype/modules/gpio/verilog`
## **Files Submitted**  
### **Verilog (Hardware)**  
- `ramDmaCI.v` – part 2.2 verilog file 
- `ramDmaCI_tb.v` – part 2.2 test bench of ramDmaCI.v
- `DMA_23.v` – part 2.3   verilog file
- `DMA_tb.v`  – part 2.3 test bench of DMA.v
- `ramDmaCi_24.v`  – part 2.4 verilog file 
- `ramDmaCi_24_tb.v`  – part 2.4 test bench of ramDmaCi_24.v 

---

## **description**  
### **part 2.2**  
we implement the first exercise and we use a test_bench with different value of imput for check our result

### **2.3**  
for this exercice we only implement the 2.3 exo (we not fusionned with the previous exercise)
you can run the test bench with following :
- `iverilog -s ramDmaCiDMATestBench -o DMAbench_23 DMA_23.v DMA_23_tb.v`
- `./DMAbench_23`
- `gtkwave DMA_23_Signals.vcd`

### **2.4**
We implement all the exercise in this module
---

---

Sebatien Devaud 315144
Charles Brossard 346186